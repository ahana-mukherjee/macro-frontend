# MACRO-SUITE
Kindly refer OCTAV repository for chat component through DJANGO and MACRO REVAMPED for initial level of prototyping through DJANGO.
