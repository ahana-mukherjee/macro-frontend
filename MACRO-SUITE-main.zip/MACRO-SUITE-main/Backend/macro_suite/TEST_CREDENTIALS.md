# Test User Credentials

## Purpose
These credentials are for development and testing purposes only. 
**IMPORTANT:** Do not use these in production environments.

## Test Users

### User 1
- **Username:** `user1`
- **Password:** `T3st_Ch@t_2025!`
- **Permissions:** Basic user access

### User 2
- **Username:** `user2`
- **Password:** `M3ss@ge_S3cure_23`
- **Permissions:** Basic user access

## Security Notes
- Change these passwords after initial setup
- Never commit real credentials to version control
- Use environment variables or secure credential management in production
