# Must-have for API communication

# Converts model objects ↔ JSON

# Makes validation easier

from rest_framework import serializers
from .models import Booking

class BookingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Booking
        fields = '__all__'
        read_only_fields = ['status', 'created_at']
