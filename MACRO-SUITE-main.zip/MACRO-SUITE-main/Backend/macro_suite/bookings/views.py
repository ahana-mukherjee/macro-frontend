from django.shortcuts import render
# Create your views here.
from rest_framework import viewsets, permissions
from .models import Booking
from .serializers import BookingSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from bookings.services import update_booking_status
from rest_framework.exceptions import NotFound

class BookingViewSet(viewsets.ModelViewSet):
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(requester=self.request.user)


class BookingStatusUpdateView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, booking_id):
        new_status = request.data.get("status")
        try:
            booking = Booking.objects.get(id=booking_id)
        except Booking.DoesNotExist:
            raise NotFound(f"Booking with id {booking_id} not found.")
            
        if request.user != booking.artist:
            return Response({"error": "Only the artist can update the booking status."}, status=403)

        update_booking_status(booking, new_status)
        return Response({"success": f"Booking status updated to {new_status}"})
