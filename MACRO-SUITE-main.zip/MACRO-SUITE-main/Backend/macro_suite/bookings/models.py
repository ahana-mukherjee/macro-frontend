# Create your models here.
from django.db import models
from django.conf import settings

class Booking(models.Model):
    STATUS_CHOICES = [
        ('requested', 'Requested'),
        ('accepted', 'Accepted'),
        ('declined', 'Declined'),
        ('completed', 'Completed'),
    ]

    artist = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='bookings_received')
    requester = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='bookings_made')
    event_date = models.DateTimeField()
    event_location = models.CharField(max_length=255)
    details = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='requested')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.requester} → {self.artist} on {self.event_date}"

class Meta:
    indexes = [
        models.Index(fields=["artist"]),
        models.Index(fields=["requester"]),
        models.Index(fields=["status"]),
    ]