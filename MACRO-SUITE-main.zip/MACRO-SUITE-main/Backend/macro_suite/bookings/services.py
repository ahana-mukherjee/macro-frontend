from django.core.mail import send_mail
from django.conf import settings
from .models import Booking

def update_booking_status(booking: Booking, new_status: str):
    old_status = booking.status
    booking.status = new_status
    booking.save()

    if new_status != old_status:
        notify_users_booking_status_change(booking)

def notify_users_booking_status_change(booking: Booking):
    subject = f"Your booking has been {booking.status.capitalize()}"
    message = f"""
    Hi {booking.requester.username},

    Your booking with artist {booking.artist.username} for {booking.event_date} at {booking.event_location}
    has been {booking.status.upper()}.

    Details:
    {booking.details}

    Thank you,
    MACRO Team
    """
    send_mail(
        subject,
        message,
        settings.DEFAULT_FROM_EMAIL,
        [booking.requester.email],
        fail_silently=False
    )
