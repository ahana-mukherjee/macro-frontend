from django.test import TestCase
# Create your tests here.
from rest_framework.test import APITestCase
from django.contrib.auth import get_user_model
from .models import Follow

User = get_user_model()

class FollowTests(APITestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username="u1", password="pass")
        self.user2 = User.objects.create_user(username="u2", password="pass")
        self.client.login(username="u1", password="pass")

    def test_follow_unfollow(self):
        # Follow
        res = self.client.post(f'/follows/follow/{self.user2.id}/')
        self.assertEqual(res.status_code, 201)
        self.assertEqual(Follow.objects.count(), 1)

        # Unfollow
        res = self.client.delete(f'/follows/unfollow/{self.user2.id}/')
        self.assertEqual(res.status_code, 204)
        self.assertEqual(Follow.objects.count(), 0)
