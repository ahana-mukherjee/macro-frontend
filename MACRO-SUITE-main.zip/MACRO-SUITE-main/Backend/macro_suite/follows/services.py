from .models import Follow
from django.contrib.auth import get_user_model
from django.shortcuts import get_object_or_404

User = get_user_model()

def follow_user(follower, following_id):
    following = get_object_or_404(User, id=following_id)
    if follower == following:
        raise ValueError("You can't follow yourself.")
    follow_obj, created = Follow.objects.get_or_create(follower=follower, following=following)
    return follow_obj, created

def unfollow_user(follower, following_id):
    follow_qs = Follow.objects.filter(follower=follower, following_id=following_id)
    deleted, _ = follow_qs.delete()
    return deleted
