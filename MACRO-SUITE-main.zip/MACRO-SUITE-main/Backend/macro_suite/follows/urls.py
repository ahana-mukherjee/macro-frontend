from django.urls import path
from . import views

urlpatterns = [
    path('follow/<int:user_id>/', views.FollowUserView.as_view(), name='follow-user'),
    path('unfollow/<int:user_id>/', views.UnfollowUserView.as_view(), name='unfollow-user'),
    path('followers/<int:user_id>/', views.FollowersListView.as_view(), name='user-followers'),
    path('following/<int:user_id>/', views.FollowingListView.as_view(), name='user-following'),
]
