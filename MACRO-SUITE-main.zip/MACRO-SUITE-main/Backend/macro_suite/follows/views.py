# follows/views.py
from django.shortcuts import render
from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.contrib.auth import get_user_model
from .models import Follow
from .serializers import FollowSerializer, UserFollowListSerializer
from .services import follow_user, unfollow_user
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
User = get_user_model()

class FollowUserView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, user_id):
        try:
            follow_obj, created = follow_user(request.user, user_id)
            serializer = FollowSerializer(follow_obj)
            return Response(serializer.data, status=status.HTTP_201_CREATED if created else status.HTTP_200_OK)
        except ValueError as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UnfollowUserView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request, user_id):
        try:
            deleted = unfollow_user(request.user, user_id)
            if deleted:
                return Response(status=status.HTTP_204_NO_CONTENT)
            else:
                # More detailed error message if follow relationship doesn't exist
                return Response({"detail": "You are not following this user."}, status=status.HTTP_404_NOT_FOUND)
        except Follow.DoesNotExist:
            return Response({"detail": "Follow relationship does not exist."}, status=status.HTTP_404_NOT_FOUND)

class FollowersListView(generics.ListAPIView):
    serializer_class = UserFollowListSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = User.objects.get(id=self.kwargs['user_id'])
        # Optimize the query to retrieve the followers with the User data in one query
        return user.follower_set.select_related('follower').distinct()

    def list(self, request, *args, **kwargs):
        queryset = User.objects.filter(id__in=self.get_queryset())
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

class FollowingListView(generics.ListAPIView):
    serializer_class = UserFollowListSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = User.objects.get(id=self.kwargs['user_id'])
        # Optimize the query to retrieve the following with the User data in one query
        return user.following_set.select_related('following').distinct()

    def list(self, request, *args, **kwargs):
        queryset = User.objects.filter(id__in=self.get_queryset())
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
