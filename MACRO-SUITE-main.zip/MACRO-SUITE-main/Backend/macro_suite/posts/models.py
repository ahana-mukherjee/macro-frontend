from django.db import models
# Create your models here.
from django.conf import settings

class Post(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="posts")
    content = models.TextField(blank=True)
    media = models.FileField(upload_to="posts/media/", blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_audio = models.BooleanField(default=False)
    is_video = models.BooleanField(default=False)
    is_image = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user.username}'s post at {self.created_at}"

class Meta:
    indexes = [
        models.Index(fields=["user"]),
        models.Index(fields=["created_at"]),
    ]
