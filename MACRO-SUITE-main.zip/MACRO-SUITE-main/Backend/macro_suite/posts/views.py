# posts/views.py
from rest_framework import viewsets, permissions
from rest_framework import filters
from django_filters.rest_framework import DjangoFilterBackend
from .models import Post
from .serializers import PostSerializer

class PostViewSet(viewsets.ModelViewSet):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['user', 'created_at', 'updated_at']  # Add filtering fields here
    ordering_fields = ['created_at', 'updated_at']  # Enable ordering by these fields
    ordering = ['-created_at']  # Default ordering, newest first

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
