import asyncio
import websockets
import json

async def test_websocket():
    # Replace with the actual chat room ID you created
    chat_room_id = 1  # Use the ID of the chat room you just created
    uri = f"ws://localhost:8000/ws/chat/{chat_room_id}/"
    try:
        async with websockets.connect(uri) as websocket:
            # Simulate a message from user1
            test_message = {
                'type': 'chat_message',
                'message': 'Hello from user1!',
                'sender_id': 2,  # Assuming user1 has ID 2
                'chatroom_id': chat_room_id
            }
            
            # Send the message
            await websocket.send(json.dumps(test_message))
            
            # Wait for a response
            try:
                response = await websocket.recv()
                print(f"Received response: {response}")
            except websockets.exceptions.ConnectionClosed:
                print("WebSocket connection closed")
    
    except Exception as e:
        print(f"WebSocket connection error: {e}")

# Run the test
if __name__ == '__main__':
    asyncio.run(test_websocket())
