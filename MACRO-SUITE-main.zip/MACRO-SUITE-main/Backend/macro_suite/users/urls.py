# users/urls.py

from django.urls import path
from .views import UserProfileView, PasswordChangeView

urlpatterns = [
    path('profile/', UserProfileView.as_view(), name='user-profile'),  # For GET and PUT profile operations
    path('change-password/', PasswordChangeView.as_view(), name='change-password'),  # For password change
]
