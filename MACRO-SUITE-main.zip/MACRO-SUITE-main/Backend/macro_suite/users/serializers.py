from rest_framework import serializers
from .models import User

class UserSerializer(serializers.ModelSerializer):
    avatar_url = serializers.ImageField(source='avatar', required=False, allow_null=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name', 'email', 'avatar', 'avatar_url']
        read_only_fields = ['id', 'avatar']  # Assuming avatar shouldn't be modified by the API directly
