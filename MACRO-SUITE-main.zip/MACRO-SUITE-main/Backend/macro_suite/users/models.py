# Create your models here.
from django.contrib.auth.models import AbstractUser
from django.db import models

def user_avatar_upload_path(instance, filename):
    return f'avatars/user_{instance.id}/{filename}'

class User(AbstractUser):
    email = models.EmailField(unique=True)
    bio = models.TextField(blank=True, null=True)
    avatar = models.ImageField(
    upload_to=user_avatar_upload_path,
    blank=True,
    null=True,
    default='avatars/default_avatar.png'  # Specify the default image path
)
    is_artist = models.BooleanField(default=False)

    def __str__(self):
        return self.username
