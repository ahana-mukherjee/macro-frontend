# MACRO-SUITE Backend Documentation

## Overview

This project is a Django REST API backend for a social platform featuring:
- User authentication and profile management
- Bookings between users (e.g., for artists)
- Chat functionality (private rooms, messages)
- Follow system (users can follow/unfollow each other)
- Posts (with media support)
- Secure credential handling via environment variables

---

## Directory & File Structure

```
Backend/
├── macro_suite/           # Main Django project folder
│   ├── __init__.py
│   ├── settings.py        # Project settings (uses .env for secrets)
│   ├── urls.py            # Root URL configuration
│   ├── asgi.py / wsgi.py  # ASGI/WGI entrypoints
│   ├── .env               # Environment variables (NOT tracked by git)
│   ├── chat/              # Chat app (rooms, messages)
│   ├── bookings/          # Booking app (artist bookings)
│   ├── follows/           # Following/unfollowing users
│   ├── posts/             # User posts/media
│   ├── users/             # Custom user model and profile
│   └── ...
├── requirements.txt       # Python dependencies
├── .gitignore             # Git ignore rules (.env, venv, etc)
├── TEST_CREDENTIALS.md    # Sample test users (do NOT use in prod)
└── README.md              # This documentation
```

---

## Features Implemented

### 1. User Management
- Custom `User` model with fields: username, email, bio, avatar, is_artist
- Profile management API (view/update profile)
- Password change functionality
- **TODO**: User registration and login endpoints need to be implemented

### 2. Bookings
- Bookings between users (e.g., artist/fan)
- API for creating, updating, and retrieving bookings
- Only the artist can update the booking status
- Robust error handling (404s, permission checks)

### 3. Chat
- Private chat rooms between two users
- Unique constraint to prevent duplicate rooms
- Message model linked to chat room (sender, content, is_read, timestamp)
- (ASGI/Channels setup is present but Redis config was removed for now)

### 4. Follow System
- Users can follow/unfollow each other
- List followers/following with optimized queries
- Detailed error messages for invalid operations

### 5. Posts
- Users can create posts with optional media (image/audio/video)
- Filtering and ordering supported on posts API
- Media uploads are handled (ensure MEDIA_ROOT/MEDIA_URL are set in settings)

### 6. Security & Environment
- `.env` file for all secrets and DB credentials (excluded from git)
- `.gitignore` ensures sensitive files are not tracked
- Example credentials provided in `TEST_CREDENTIALS.md` (for development only)

---

## File Responsibilities

- **settings.py**: Django settings, loads secrets from `.env`, configures apps, DB, media, etc.
- **urls.py**: Central routing for all API endpoints
- **chat/models.py**: Models for chat rooms and messages
- **chat/views.py**: (To be implemented) API endpoints for chat
- **bookings/views.py**: API endpoints for booking management
- **follows/views.py**: API endpoints for follow/unfollow, followers, following
- **posts/models.py**: Post model (with media support)
- **posts/views.py**: API endpoints for posts, filtering, ordering
- **users/models.py**: Custom user model
- **users/views.py**: Profile and password management endpoints
- **users/serializers.py**: Serializers for user data
- **users/urls.py**: User-related API routes
- **.env**: Environment variables (not tracked by git)
- **.gitignore**: Ensures `.env` and other sensitive/dev files are not tracked
- **TEST_CREDENTIALS.md**: Sample test users for development

---

## What is Working
- User profile viewing and updating
- Password change functionality
- Bookings between users with permission checks
- Follow/unfollow system with robust error handling
- Posts creation and media upload
- Basic API endpoints structure
- Environment configuration and security setup (`.env`, `.gitignore`)

## What is Partially Working/In Progress
- Chat system (models defined, endpoints needed)
- User authentication (profile updates work, but registration/login needed)
- Media handling (models support it, but configuration needed)

## What Needs Attention/Next Steps
- Implement chat API endpoints and websocket consumers
- Add tests for all major features
- Review and improve security settings before production (e.g., DEBUG=False, ALLOWED_HOSTS, secure email backend, etc)
- Set up CI/CD and deployment scripts
- Add API documentation (Swagger/OpenAPI)

---

## Environment Variables

Create a `.env` file in the `macro_suite` directory with the following template:

```env
```pip install macro-suite_requirements.txt```

Also create a .env file in this directory with template:

SECRET_KEY=<key>

DEBUG=True

DB_NAME=<db_name>

DB_USER=<db_user>

DB_PASSWORD=<password>

DB_HOST=<db_host>

DB_PORT=5432
```

Replace the placeholders (`<...>`) with your actual values. Never commit the actual `.env` file with real credentials to version control.

---

## Onboarding
1. Clone the repo
2. Create a virtual environment and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate  # or venv\Scripts\activate on Windows
   pip install -r requirements.txt
   ```
3. Copy `.env.example` to `.env` and fill in your secrets
4. Run migrations:
   ```bash
   python manage.py migrate
   ```
5. Create a superuser:
   ```bash
   python manage.py createsuperuser
   ```
6. Run the server:
   ```bash
   python manage.py runserver
   ```

---

For any questions or issues, please check the code comments or contact the maintainers.
